<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class HyperpayController extends Controller
{
   // no code
}
