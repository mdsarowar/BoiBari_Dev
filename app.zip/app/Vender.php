<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Vender extends Model
{
    //
}
