<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class RMA extends Model
{
    protected $fillable = ['reason','status'];
}
