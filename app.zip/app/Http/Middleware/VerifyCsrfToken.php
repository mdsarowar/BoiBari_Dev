<?php

namespace App\Http\Middleware;

use Illuminate\Foundation\Http\Middleware\VerifyCsrfToken as Middleware;

class VerifyCsrfToken extends Middleware
{
    /**
     * Indicates whether the XSRF-TOKEN cookie should be set on the response.
     *
     * @var bool
     */
    protected $addHttpCookie = true;

    /**
     * The URIs that should be excluded from CSRF verification.
     *
     * @var array
     */
    protected $except = [

        'paidviapaytmsuccess',
        'wallet/success/using/paytm',
        'payviacashfree/success',
        'payvia/sslcommerze/success',
        'payvias/sslcommerze/cancel',
        'payvia/sslcommerze/fail',
        'payvia/sslcommerze/ipn',
        'payvia/iyzcio/success',
        'success/aamarpay',
        'pay/for/subscription/paytm/success',
        'stripe/3ds'
    ];
}
