<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
use Kyslik\ColumnSortable\Sortable;

class review extends Model
{
    protected $fillable=[
	
		'remark',

	];
}
