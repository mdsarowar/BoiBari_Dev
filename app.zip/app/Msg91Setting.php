<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Msg91Setting extends Model
{
    public $timestamps = false;

    protected $table = 'msg91_settings';
}
