<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class UserPayAmount extends Model
{
    //
}
