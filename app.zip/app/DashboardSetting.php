<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class DashboardSetting extends Model
{
    //
}
