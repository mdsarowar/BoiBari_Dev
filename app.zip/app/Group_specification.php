<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Group_specification extends Model
{
    protected $fillable=[
	
		'name','status'

	];
}
