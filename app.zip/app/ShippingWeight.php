<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class ShippingWeight extends Model
{
    //
}
