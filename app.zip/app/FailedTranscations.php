<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class FailedTranscations extends Model
{
    //
}
