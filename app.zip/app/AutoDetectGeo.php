<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class AutoDetectGeo extends Model
{
    //
}
