<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Vender_category extends Model
{
    protected $fillable = [
        'title',
    ];


}
