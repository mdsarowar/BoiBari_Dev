<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Mostsearched extends Model
{
    protected $fillable = ['keyword','count'];
}
