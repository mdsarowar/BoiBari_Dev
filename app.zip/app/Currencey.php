<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Currencey extends Model
{
     protected $fillable = [

     		'currencey_code','value',

     ];
}
