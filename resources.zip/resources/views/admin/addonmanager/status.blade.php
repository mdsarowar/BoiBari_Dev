<label class="switch">
    <input class="toggle_addon" type="checkbox" data-addon="{{ $name }}" {{ $status =='1' ? "checked" : "" }}>
    <span class="knob"></span>
</label>