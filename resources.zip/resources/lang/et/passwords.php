<?php

return array (
  'password' => 'Paroolid peavad olema vähemalt kuus tähemärki ja vastama kinnitusele.',
  'reset' => 'Teie parool on lähtestatud!',
  'sent' => 'Oleme parooli lähtestamise lingi e-postiga saatnud!',
  'token' => 'Selle parooli lähtestamise tunnus on kehtetu.',
  'user' => 'Me ei leia selle e-posti aadressiga kasutajat.',
);
