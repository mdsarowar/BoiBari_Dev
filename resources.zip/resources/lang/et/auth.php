<?php

return array (
  'failed' => 'Need mandaadid ei vasta meie andmetele.',
  'throttle' => 'Liiga palju sisselogimiskatseid. Proovige uuesti :seconds sekundi pärast.',
);
