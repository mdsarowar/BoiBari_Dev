<?php

return array (
  'next' => 'Следующий "',
  'previous' => '«Предыдущий',
);
