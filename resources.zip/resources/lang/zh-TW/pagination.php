<?php

return array (
  'next' => '下一個 ”',
  'previous' => '«上一頁',
);
