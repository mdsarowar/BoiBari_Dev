<?php

return array (
  'failed' => '這些憑據與我們的記錄不匹配。',
  'throttle' => '登錄嘗試過多。請在1秒鐘後重試。',
);
