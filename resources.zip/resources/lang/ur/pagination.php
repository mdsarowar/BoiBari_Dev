<?php

return array (
  'next' => 'اگلے "',
  'previous' => '«پچھلا',
);
