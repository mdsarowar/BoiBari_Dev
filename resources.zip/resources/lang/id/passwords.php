<?php

return array (
  'password' => 'Kata sandi minimal harus enam karakter dan cocok dengan konfirmasi.',
  'reset' => 'Kata sandi Anda telah disetel ulang!',
  'sent' => 'Kami telah mengirim e-mail tautan atur ulang kata sandi Anda!',
  'token' => 'Token atur ulang kata sandi ini tidak valid.',
  'user' => 'Kami tidak dapat menemukan pengguna dengan alamat email itu.',
);
