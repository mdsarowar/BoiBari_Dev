<?php

return array (
  'next' => 'Lanjut "',
  'previous' => '" Sebelumnya',
);
