<?php

return array (
  'next' => 'التالى "',
  'previous' => '" السابق',
);
