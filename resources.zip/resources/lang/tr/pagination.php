<?php

return array (
  'next' => 'Sonraki "',
  'previous' => '«Önceki',
);
