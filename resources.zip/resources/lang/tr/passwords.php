<?php

return array (
  'password' => 'Parolalar en az altı karakterden oluşmalı ve onayla eşleşmelidir.',
  'reset' => 'Şifreniz sıfırlandı!',
  'sent' => 'Şifre sıfırlama bağlantınızı e-postayla gönderdik!',
  'token' => 'Bu şifre sıfırlama kodu geçersiz.',
  'user' => 'Bu e-posta adresine sahip bir kullanıcı bulamıyoruz.',
);
