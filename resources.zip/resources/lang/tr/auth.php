<?php

return array (
  'failed' => 'Bu kimlik bilgileri kayıtlarımızla eşleşmiyor.',
  'throttle' => 'Çok fazla giriş denemesi. Lütfen :seconds saniye içinde tekrar deneyin.',
);
