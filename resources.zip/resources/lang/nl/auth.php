<?php

return array (
  'failed' => 'Deze gegevens komen niet overeen met onze gegevens.',
  'throttle' => 'Te veel inlogpogingen. Probeer het over :seconds seconden opnieuw.',
);
