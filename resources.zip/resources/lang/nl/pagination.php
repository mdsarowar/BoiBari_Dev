<?php

return array (
  'next' => 'De volgende "',
  'previous' => '«Vorige',
);
