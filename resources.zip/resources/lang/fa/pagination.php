<?php

return array (
  'next' => 'بعد "',
  'previous' => '«قبلی',
);
