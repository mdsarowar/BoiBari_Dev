<?php

return array (
  'next' => 'Próximo "',
  'previous' => '«Anterior',
);
