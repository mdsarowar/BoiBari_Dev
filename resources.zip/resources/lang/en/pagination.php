<?php

return array (
  'next' => 'Next »',
  'previous' => '« Previous',
);
