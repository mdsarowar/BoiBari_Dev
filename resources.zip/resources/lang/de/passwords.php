<?php

return array (
  'password' => 'Passwörter müssen mindestens sechs Zeichen lang sein und mit der Bestätigung übereinstimmen.',
  'reset' => 'Dein Passwort wurde zurück gesetzt!',
  'sent' => 'Wir haben Ihren Link zum Zurücksetzen Ihres Passworts per E-Mail gesendet!',
  'token' => 'Dieses Token zum Zurücksetzen des Passworts ist ungültig.',
  'user' => 'Wir können keinen Benutzer mit dieser E-Mail-Adresse finden.',
);
