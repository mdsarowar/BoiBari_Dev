<?php

return array (
  'next' => 'Nächster "',
  'previous' => '" Bisherige',
);
