<?php

return array (
  'password' => 'Parolele trebuie să aibă cel puțin șase caractere și să corespundă confirmării.',
  'reset' => 'Parola ta a fost resetata!',
  'sent' => 'Am trimis prin e-mail linkul de resetare a parolei!',
  'token' => 'Acest simbol de resetare a parolei nu este valid.',
  'user' => 'Nu putem găsi un utilizator cu acea adresă de e-mail.',
);
