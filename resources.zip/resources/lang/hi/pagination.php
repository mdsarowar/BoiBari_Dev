<?php

return array (
  'next' => 'आगे "',
  'previous' => '" पिछला',
);
